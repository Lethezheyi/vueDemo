/* 
项目的中间件 middleware.js
用来和后端的数据进行对接
*/

// 引入express框架
let express = require('express');
let app = express();

// 跨域解决方案
app.all('*',function(req,res,next){
    // 任何网址都可以访问
    res.header("Access-Control-Allow-Origin","*");
    // 允许的请求方式
    res.header("Access-Control-Allow-Methods","PUT,POST,GET,DE;ETE,OPTIONS");
    // X-Requester-With,判断请求方式是普通请求还是ajax请求
    res.header("Access-Control-Allow-Headers","X-Requester-With");
    res.header("Content-Type","application/json;charset=utf-8");
    next();
})

app.get('/search',(req,res)=>{
    console.log(req.query);
    let _searchKey = req.query.searchKey;
    // 临时数据，先把流程走通
    let _tempGoods = [{
        name:'好看的男装',
        price:99
    },{
        name:'美丽的女装',
        price:98
    },{
        name:'可爱的童装',
        price:97
    },{
        name:'干活的工作服',
        price:96
    }]
    // console.log(req.query.searchKey);
    // 过滤结果
    let _filterGoods = _tempGoods.filter(n=>{
        return n.name.indexOf(_searchKey) !==-1;
    })
    // 因为filter只返回结果为true的，所以需要二次判断
    let _resultObj = _filterGoods.length > 0?_filterGoods:{msg:"找不到商品！"}
    res.send(_resultObj);
    // 本意是要在这个中间件里去操作mmysql的crud的，
    // 但是,我们还没有mysql，
    // 所以,我们在这里写一些假数据,用于模拟搜索过程,这只是一个思路,并不是真实生产开发环境的搜索过程,
    // 因为真实的生产环境,它的后台的搜素功能由java /.net来负责的，咱们前端只负责传入参数，调用接口

})

app.get('/get_tabBtn_list',(req,res)=>{
    let _d=['推荐','居家生活','服饰鞋包','美食酒水','个护清洁','母婴亲子','运动旅行','数码家电','严选全球']
    res.send(_d);
})

app.listen(3344,()=>{
    console.log("高仿网易严选第二版中间件已经启动");
})

